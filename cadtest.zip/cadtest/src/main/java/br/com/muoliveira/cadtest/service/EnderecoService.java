package br.com.muoliveira.cadtest.service;

import br.com.muoliveira.cadtest.model.Endereco;
import br.com.muoliveira.cadtest.repository.EnderecoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnderecoService {

    @Autowired
    private EnderecoRepository enderecoRepository;

    public void salvarEndereco(List<Endereco> enderecos){
        if(enderecos!=null && enderecos.size()>0){
            enderecos.forEach(endereco -> enderecoRepository.save(endereco));
        }
    }

    public void deletarEnderecos(List<Endereco> enderecos){
        if(enderecos!=null && enderecos.size()>0){
            enderecos.forEach(endereco -> enderecoRepository.delete(endereco));
        }
    }

}
