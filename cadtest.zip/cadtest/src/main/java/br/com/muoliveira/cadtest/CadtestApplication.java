package br.com.muoliveira.cadtest;

import com.sun.faces.config.ConfigureListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import javax.faces.webapp.FacesServlet;

@SpringBootApplication
public class CadtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadtestApplication.class, args);
	}

	@Bean
	public ServletRegistrationBean facesServletRegistration(){
		ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean<>(new FacesServlet(),"*.xhtml");
		servletRegistrationBean.setLoadOnStartup(1);
		servletRegistrationBean.addUrlMappings("*.jsf");
		return servletRegistrationBean;
	}

	@Bean
	public ServletContextInitializer servletContextInitializer(){
		return servletContext -> {
			servletContext.setInitParameter("com.sun.faces.forceLoadConfiguration",Boolean.TRUE.toString());
			servletContext.setInitParameter("primefaces.THEME","redmond");
		};
	}

	@Bean
	public ServletListenerRegistrationBean<ConfigureListener> jsfConfigureListener(){
		return new ServletListenerRegistrationBean<>(new ConfigureListener());
	}

	@Bean
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}

}
