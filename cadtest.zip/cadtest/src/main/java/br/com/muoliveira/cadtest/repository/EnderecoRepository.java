package br.com.muoliveira.cadtest.repository;

import br.com.muoliveira.cadtest.model.Endereco;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnderecoRepository extends JpaRepository<Endereco, Integer> {

}
