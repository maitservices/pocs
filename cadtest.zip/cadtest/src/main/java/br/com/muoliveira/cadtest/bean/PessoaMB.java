package br.com.muoliveira.cadtest.bean;

import br.com.muoliveira.cadtest.model.Endereco;
import br.com.muoliveira.cadtest.model.Pessoa;
import br.com.muoliveira.cadtest.service.EnderecoService;
import br.com.muoliveira.cadtest.service.PessoaService;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;


@Named(value="pessoaMB")
@ConversationScoped
public class PessoaMB {

    @Getter
    @Setter
    private List<Pessoa> pessoas= new ArrayList<>();

    @Getter
    @Setter
    private Pessoa pessoa;

    @Getter
    @Setter
    private Endereco endereco;

    @Autowired
    private PessoaService pessoaService;

    @Autowired
    private EnderecoService enderecoService;

    @Getter
    @Setter
    ArrayList<String> estados = new ArrayList<String>();

    @PostConstruct
    public void listarTodos() {
        pessoas= pessoaService.listarTodos();
        listarEstados();
    }

    public void novaPessoa(){
        pessoa = new Pessoa();
        pessoa.setEnderecos (new ArrayList<>());
        endereco = new Endereco();
    }

    public void salvarPessoa(){
        String msg = pessoaService.salvarPessoa(pessoa);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(msg));
        listarTodos();
        novaPessoa();
    }

    public void deletarPessoa(){
        String msg = pessoaService.deletarPessoa(pessoa);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(msg));
        listarTodos();
        novaPessoa();
    }

    public void adicionarEnderecoPessoa(){
        if(pessoa!=null && pessoa.getEnderecos()==null){
            pessoa.setEnderecos(new ArrayList<>());
        }
        if(endereco==null){
            endereco = new Endereco();
        }
        endereco.setPessoa(pessoa);
        pessoa.getEnderecos().add(endereco);
        endereco = new Endereco();

    }

    public void listarEstados(){
        estados.add("AC");
        estados.add("AL");
        estados.add("AP");
        estados.add("AM");
        estados.add("BA");
        estados.add("CE");
        estados.add("DF");
        estados.add("ES");
        estados.add("GO");
        estados.add("MA");
        estados.add("MT");
        estados.add("MS");
        estados.add("MG");
        estados.add("PA");
        estados.add("PB");
        estados.add("PR");
        estados.add("PE");
        estados.add("PI");
        estados.add("RJ");
        estados.add("RN");
        estados.add("RS");
        estados.add("RO");
        estados.add("RR");
        estados.add("SC");
        estados.add("SP");
        estados.add("SE");
        estados.add("TO");
    }
    public Integer getTamanhoDaLista() {
        return pessoas.size();
    }

    public void setTamanhoDaLista(Integer size) {
        // isso é utilizado pelo primefaces.
    }
}
