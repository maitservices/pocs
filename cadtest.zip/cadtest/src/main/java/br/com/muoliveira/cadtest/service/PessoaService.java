package br.com.muoliveira.cadtest.service;

import br.com.muoliveira.cadtest.model.Pessoa;
import br.com.muoliveira.cadtest.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class PessoaService {

    @Autowired
    private PessoaRepository pessoaRepository;

    @Autowired
    private EnderecoService enderecoService;
    public List<Pessoa> listarTodos() {
        return pessoaRepository.findAll();
    }

    public String salvarPessoa(Pessoa pessoa){
        if(pessoa!=null && pessoa.getNome()!=null && pessoa.getNome().trim().length()>2) {
            pessoaRepository.save(pessoa);
            return "Salvo com sucesso!";
        }else{
            return"Informe pelo meno o 'Nome'!";
        }
    }

    public String deletarPessoa(Pessoa pessoa){
        if(pessoa!=null && pessoa.getId()!=null && pessoa.getId().intValue()>0) {
            enderecoService.deletarEnderecos(pessoa.getEnderecos());
            pessoaRepository.delete(pessoa);
            return"DELETADO com sucesso!";

        }else{
            return"Selecione uma pessoa da lista!";
        }
    }
}
