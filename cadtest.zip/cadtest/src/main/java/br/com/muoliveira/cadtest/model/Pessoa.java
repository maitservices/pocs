package br.com.muoliveira.cadtest.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String nome;
    private Integer idade;

    private String sexo;

    @OneToMany(fetch = FetchType.EAGER,mappedBy="pessoa", cascade = CascadeType.ALL,     orphanRemoval=true)
    private List<Endereco> enderecos;


}

