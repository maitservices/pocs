package br.com.muoliveira.cadtest.controller;

import br.com.muoliveira.cadtest.model.Pessoa;
import br.com.muoliveira.cadtest.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    @Autowired
    PessoaRepository pessoaRepository;

    @PostMapping
    public void incluirNovaPessoa(@RequestBody Pessoa pessoa){
        pessoaRepository.save(pessoa);
    }

    @PutMapping
    public void atualizarPessoa(@RequestBody Pessoa pessoa){
        pessoaRepository.save(pessoa);
    }

    @DeleteMapping("/{id}")
    public void removerPessoa(@PathVariable Integer id){
        pessoaRepository.deleteById(id);
    }

    @GetMapping
    public List<Pessoa> listarTodos(){
        return pessoaRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Pessoa> pessoaPorId(@PathVariable Integer id){
        return pessoaRepository.findById(id);
    }
}
