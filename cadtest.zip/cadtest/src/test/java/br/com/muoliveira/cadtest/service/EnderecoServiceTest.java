package br.com.muoliveira.cadtest.service;

import br.com.muoliveira.cadtest.model.Endereco;
import br.com.muoliveira.cadtest.model.Pessoa;
import br.com.muoliveira.cadtest.repository.EnderecoRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;


@SpringBootTest
public class EnderecoServiceTest {

    @InjectMocks
    private EnderecoService enderecoService;

    @Mock
    private EnderecoRepository enderecoRepository;

    @Test
    public void salvarEnderecoTesteSucesso(){
        Pessoa p = Pessoa.builder().nome("murilo").idade(33).sexo("m").build();
        Endereco endereco =Endereco.builder().pessoa(p).estado("PR").cidade("STI").logradouro("sdf").numero("sn").build();
        enderecoService.salvarEndereco(Arrays.asList(endereco));

    }
}