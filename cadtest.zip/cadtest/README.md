#Como executar a aplicação

Esse é um projeto web que utiliza frameworks e ferramentas que ajudam na agilidade e entendimento do código: 
spring-boot, lombok e docker.

Requisitos:
JDK 1.8,
Maven,
IDE IntelliJ, Docker juntamente com Docker-Compose


1:
    Após baixar o projeto, utilizando a IDE IntelliJ para importar o projeto.

2:
    Abra o terminal na pasta raiz do projeto e execute o seguinte comando:
    $mvn clean install -U

3:
    Execute o comando abaixo para inicializar o postgresql.
    Acessando pelo 'terminal' a pasta 'docker' na raiz do projeto, execute o seguinte comando:
    $docker-compose up -d

4: 
    Com os passos anteriores executados com sucesso, para rodar a aplicação execute o seguinte comando:
    $mvn spring-boot:run

5: 
    Para abrir a aplicação, acesse: http://localhost:8080/pessoa.jsf